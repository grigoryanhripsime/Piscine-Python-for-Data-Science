# ft_package

A sample package for counting values in a list.