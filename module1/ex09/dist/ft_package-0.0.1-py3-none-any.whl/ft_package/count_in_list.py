def count_in_list(lst: list, word: str) -> int:
    """
    This method returns the number of arguments in in list.
    """
    return lst.count(word)